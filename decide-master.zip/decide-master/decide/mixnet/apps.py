from django.apps import AppConfig


class MixnetConfig(AppConfig):
    name = 'mixnet'
