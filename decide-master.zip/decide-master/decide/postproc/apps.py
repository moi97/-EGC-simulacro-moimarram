from django.apps import AppConfig


class PostProceConfig(AppConfig):
    name = 'postproc'
